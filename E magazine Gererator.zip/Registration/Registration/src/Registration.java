


public class Registration
{
    public static void main(String[] args)
    {
        Reg e=new Reg();
            e.setVisible(true);
    }  
}
